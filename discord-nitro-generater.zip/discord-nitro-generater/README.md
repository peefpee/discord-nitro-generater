<h1 align="center"> Discord Nitro Generator </h1>

Requirements:
* Python 3


Usage:
1. Launch `main.py`
